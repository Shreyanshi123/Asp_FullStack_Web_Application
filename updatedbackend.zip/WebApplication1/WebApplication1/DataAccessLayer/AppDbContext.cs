﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.Models.Cancellation_Model_;
using WebApplication1.Models.Flight_Model_;
using WebApplication1.Models.Payment_Model_;
using WebApplication1.Models.Reservation_Model_;
using WebApplication1.Models.SeatBooking_Model_;
using WebApplication1.Models.User_Model_;

namespace WebApplication1.DataAccessLayer
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Flight> Flights { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Reservation> Reservations { get; set; }
        public DbSet<SeatBooking> SeatBookings { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Cancellation> Cancellations { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure relationships
            modelBuilder.Entity<Reservation>()
                .HasOne(r => r.Flight)
                .WithMany(f => f.Reservations)
                .HasForeignKey(r => r.FlightId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Reservation>()
                .HasOne(r => r.User)
                .WithMany(u => u.Reservations)
                .HasForeignKey(r => r.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<SeatBooking>()
                .HasOne(sb => sb.Reservation)
                .WithMany(r => r.SeatBookings)
                .HasForeignKey(sb => sb.ReservationId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Payment>()
                .HasOne(p => p.Reservation)
                .WithOne(r => r.Payment)
                .HasForeignKey<Payment>(p => p.ReservationId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Cancellation>()
                .HasOne(c => c.Reservation)
                .WithOne(r => r.Cancellation)
                .HasForeignKey<Cancellation>(c => c.ReservationId)
                .OnDelete(DeleteBehavior.Cascade);
        }


    }
}
