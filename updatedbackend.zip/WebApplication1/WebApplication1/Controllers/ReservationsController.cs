﻿//using System.Security.Claims;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using WebApplication1.DataAccessLayer;
//using WebApplication1.Models.Cancellation_Model_;
//using WebApplication1.Models.Flight_Model_;
//using WebApplication1.Models.Payment_Model_;
//using WebApplication1.Models.Reservation_Model_;
//using WebApplication1.Models.SeatBooking_Model_;

//namespace WebApplication1.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ReservationsController : ControllerBase
//    {
//        private readonly AppDbContext _context;

//        public ReservationsController(AppDbContext context)
//        {
//            _context = context;
//        }

//        [HttpGet]
//        public async Task<ActionResult<IEnumerable<ReservationDto>>> GetReservations()
//        {
//            int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
//            bool isAdmin = User.IsInRole("Admin");

//            var query = _context.Reservations
//                .Include(r => r.Flight)
//                .Include(r => r.SeatBookings)
//                .AsQueryable();

//            if (!isAdmin)
//            {
//                // Regular users can only see their own reservations
//                query = query.Where(r => r.UserId == userId);
//            }

//            var reservations = await query.ToListAsync();

//            return reservations.Select(r => new ReservationDto
//            {
//                Id = r.Id,
//                FlightId = r.FlightId,
//                ReservationDate = r.ReservationDate,
//                Status = r.Status.ToString(),
//                TotalAmount = r.TotalAmount,
//                SeatBookings = r.SeatBookings.Select(sb => new SeatBookingDto
//                {
//                    Id = sb.Id,
//                    SeatNumber = sb.SeatNumber,
//                    SeatClass = sb.SeatClass.ToString(),
//                    Price = sb.Price,
//                    PassengerName = sb.PassengerName
//                }).ToList(),
//                Flight = new FlightDto
//                {
//                    Id = r.Flight.Id,
//                    FlightNumber = r.Flight.FlightNumber,
//                    AirlineName = r.Flight.AirlineName,
//                    DepartureCity = r.Flight.DepartureCity,
//                    ArrivalCity = r.Flight.ArrivalCity,
//                    DepartureTime = r.Flight.DepartureTime,
//                    ArrivalTime = r.Flight.ArrivalTime,
//                    AvailableBusinessSeats = r.Flight.AvailableBusinessSeats,
//                    AvailableEconomySeats = r.Flight.AvailableEconomySeats,
//                    BusinessClassPrice = r.Flight.BusinessClassPrice,
//                    EconomyClassPrice = r.Flight.EconomyClassPrice
//                }
//            }).ToList();
//        }

//        [HttpGet("{id}")]
//        public async Task<ActionResult<ReservationDto>> GetReservation(int id)
//        {
//            int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
//            bool isAdmin = User.IsInRole("Admin");

//            var reservation = await _context.Reservations
//                .Include(r => r.Flight)
//                .Include(r => r.SeatBookings)
//                .FirstOrDefaultAsync(r => r.Id == id);

//            if (reservation == null)
//            {
//                return NotFound();
//            }

//            // Check if the user is authorized to see this reservation
//            if (!isAdmin && reservation.UserId != userId)
//            {
//                return Forbid();
//            }

//            return new ReservationDto
//            {
//                Id = reservation.Id,
//                FlightId = reservation.FlightId,
//                ReservationDate = reservation.ReservationDate,
//                Status = reservation.Status.ToString(),
//                TotalAmount = reservation.TotalAmount,
//                SeatBookings = reservation.SeatBookings.Select(sb => new SeatBookingDto
//                {
//                    Id = sb.Id,
//                    SeatNumber = sb.SeatNumber,
//                    SeatClass = sb.SeatClass.ToString(),
//                    Price = sb.Price,
//                    PassengerName = sb.PassengerName
//                }).ToList(),
//                Flight = new FlightDto
//                {
//                    Id = reservation.Flight.Id,
//                    FlightNumber = reservation.Flight.FlightNumber,
//                    AirlineName = reservation.Flight.AirlineName,
//                    DepartureCity = reservation.Flight.DepartureCity,
//                    ArrivalCity = reservation.Flight.ArrivalCity,
//                    DepartureTime = reservation.Flight.DepartureTime,
//                    ArrivalTime = reservation.Flight.ArrivalTime,
//                    AvailableBusinessSeats = reservation.Flight.AvailableBusinessSeats,
//                    AvailableEconomySeats = reservation.Flight.AvailableEconomySeats,
//                    BusinessClassPrice = reservation.Flight.BusinessClassPrice,
//                    EconomyClassPrice = reservation.Flight.EconomyClassPrice
//                }
//            };
//        }

//        [HttpPost]
//        public async Task<ActionResult<ReservationDto>> CreateReservation(CreateReservationDto createReservationDto)
//        {
//            int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);

//            // Check if flight exists
//            var flight = await _context.Flights
//                .FirstOrDefaultAsync(f => f.Id == createReservationDto.FlightId && f.IsActive);

//            if (flight == null)
//            {
//                return BadRequest(new { message = "Flight not found or inactive" });
//            }

//            // Count seats by class
//            int businessSeatsRequested = createReservationDto.SeatBookings.Count(sb => sb.SeatClass.ToLower() == "business");
//            int economySeatsRequested = createReservationDto.SeatBookings.Count(sb => sb.SeatClass.ToLower() == "economy");

//            // Check if enough seats are available
//            if (flight.AvailableBusinessSeats < businessSeatsRequested)
//            {
//                return BadRequest(new { message = "Not enough business class seats available" });
//            }

//            if (flight.AvailableEconomySeats < economySeatsRequested)
//            {
//                return BadRequest(new { message = "Not enough economy class seats available" });
//            }

//            // Calculate total amount
//            decimal totalAmount = (businessSeatsRequested * flight.BusinessClassPrice) +
//                                  (economySeatsRequested * flight.EconomyClassPrice);

//            using var transaction = await _context.Database.BeginTransactionAsync();

//            try
//            {







//                // Create the reservation
//                var reservation = new Reservation
//                {
//                    FlightId = flight.Id,
//                    UserId = userId,
//                    ReservationDate = DateTime.UtcNow,
//                    Status = ReservationStatus.Pending,
//                    TotalAmount = totalAmount
//                };

//                _context.Reservations.Add(reservation);
//                await _context.SaveChangesAsync();

//                // Create seat bookings
//                var seatBookings = new List<SeatBooking>();

//                // Simple seat assignment algorithm - just assign sequential seats
//                // In a real system, you'd have a more sophisticated seat selection mechanism
//                int businessSeatCounter = 1;
//                int economySeatCounter = 1;

//                foreach (var bookingDto in createReservationDto.SeatBookings)
//                {
//                    var seatClass = bookingDto.SeatClass.ToLower() == "business"
//                        ? SeatClass.Business
//                        : SeatClass.Economy;

//                    string seatNumber;
//                    decimal price;

//                    if (seatClass == SeatClass.Business)
//                    {
//                        seatNumber = $"B{businessSeatCounter++}";
//                        price = flight.BusinessClassPrice;
//                    }
//                    else
//                    {
//                        seatNumber = $"E{economySeatCounter++}";
//                        price = flight.EconomyClassPrice;
//                    }

//                    var seatBooking = new SeatBooking
//                    {
//                        ReservationId = reservation.Id,
//                        SeatNumber = seatNumber,
//                        SeatClass = seatClass,
//                        Price = price,
//                        PassengerName = bookingDto.PassengerName
//                    };

//                    seatBookings.Add(seatBooking);
//                }

//                _context.SeatBookings.AddRange(seatBookings);

//                // Update available seats
//                flight.AvailableBusinessSeats -= businessSeatsRequested;
//                flight.AvailableEconomySeats -= economySeatsRequested;

//                await _context.SaveChangesAsync();
//                await transaction.CommitAsync();

//                // Return the reservation details
//                return CreatedAtAction(
//                    nameof(GetReservation),
//                    new { id = reservation.Id },
//                    new ReservationDto
//                    {
//                        Id = reservation.Id,
//                        FlightId = reservation.FlightId,
//                        ReservationDate = reservation.ReservationDate,
//                        Status = reservation.Status.ToString(),
//                        TotalAmount = reservation.TotalAmount,
//                        SeatBookings = seatBookings.Select(sb => new SeatBookingDto
//                        {
//                            Id = sb.Id,
//                            SeatNumber = sb.SeatNumber,
//                            SeatClass = sb.SeatClass.ToString(),
//                            Price = sb.Price,
//                            PassengerName = sb.PassengerName
//                        }).ToList(),
//                        Flight = new FlightDto
//                        {
//                            Id = flight.Id,
//                            FlightNumber = flight.FlightNumber,
//                            AirlineName = flight.AirlineName,
//                            DepartureCity = flight.DepartureCity,
//                            ArrivalCity = flight.ArrivalCity,
//                            DepartureTime = flight.DepartureTime,
//                            ArrivalTime = flight.ArrivalTime,
//                            AvailableBusinessSeats = flight.AvailableBusinessSeats,
//                            AvailableEconomySeats = flight.AvailableEconomySeats,
//                            BusinessClassPrice = flight.BusinessClassPrice,
//                            EconomyClassPrice = flight.EconomyClassPrice
//                        }
//                    }
//                );
//            }
//            catch (Exception ex)
//            {
//                await transaction.RollbackAsync();
//                return StatusCode(500, new { message = $"Internal server error: {ex.Message}" });
//            }
//        }

//        [HttpPut("{id}/cancel")]
//        public async Task<IActionResult> CancelReservation(int id, CreateCancellationDto cancellationDto)
//        {
//            int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
//            bool isAdmin = User.IsInRole("Admin");

//            var reservation = await _context.Reservations
//                .Include(r => r.Flight)
//                .Include(r => r.SeatBookings)
//                .Include(r => r.Payment)
//                .FirstOrDefaultAsync(r => r.Id == id);

//            if (reservation == null)
//            {
//                return NotFound();
//            }

//            // Check if the user is authorized to cancel this reservation
//            if (!isAdmin && reservation.UserId != userId)
//            {
//                return Forbid();
//            }

//            // Check if the reservation can be cancelled
//            if (reservation.Status == ReservationStatus.Cancelled)
//            {
//                return BadRequest(new { message = "Reservation is already cancelled" });
//            }

//            if (reservation.Status == ReservationStatus.Completed)
//            {
//                return BadRequest(new { message = "Completed reservations cannot be cancelled" });
//            }

//            if (reservation.Flight.DepartureTime <= DateTime.UtcNow)
//            {
//                return BadRequest(new { message = "Cannot cancel reservation after flight departure" });
//            }

//            using var transaction = await _context.Database.BeginTransactionAsync();

//            try
//            {
//                // Update reservation status
//                reservation.Status = ReservationStatus.Cancelled;

//                // Calculate refund amount (could have more complex logic based on cancellation policy)
//                // For simplicity, we'll refund 80% if payment exists
//                decimal refundAmount = 0;
//                if (reservation.Payment != null && reservation.Payment.Status == PaymentStatus.Completed)
//                {
//                    refundAmount = reservation.TotalAmount * 0.8m;

//                    // Update payment status
//                    reservation.Payment.Status = PaymentStatus.Refunded;
//                }

//                // Create cancellation record
//                var cancellation = new Cancellation
//                {
//                    ReservationId = reservation.Id,
//                    CancellationDate = DateTime.UtcNow,
//                    RefundAmount = refundAmount,
//                    Reason = cancellationDto.Reason
//                };

//                _context.Cancellations.Add(cancellation);

//                // Return seats to available inventory
//                var flight = reservation.Flight;
//                foreach (var booking in reservation.SeatBookings)
//                {
//                    if (booking.SeatClass == SeatClass.Business)
//                    {
//                        flight.AvailableBusinessSeats++;
//                    }
//                    else
//                    {
//                        flight.AvailableEconomySeats++;
//                    }
//                }

//                await _context.SaveChangesAsync();
//                await transaction.CommitAsync();

//                return Ok(new { message = "Reservation cancelled successfully", refundAmount });
//            }
//            catch (Exception ex)
//            {
//                await transaction.RollbackAsync();
//                return StatusCode(500, new { message = $"Internal server error: {ex.Message}" });
//            }
//        }

//    }
//}


using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.DataAccessLayer;
using WebApplication1.Models.Cancellation_Model_;
using WebApplication1.Models.Flight_Model_;
using WebApplication1.Models.Payment_Model_;
using WebApplication1.Models.Reservation_Model_;
using WebApplication1.Models.SeatBooking_Model_;
using Microsoft.Extensions.Logging;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationsController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<ReservationsController> _logger;

        public ReservationsController(AppDbContext context, ILogger<ReservationsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // -----------------------------------
        // GET ALL RESERVATIONS (WITH FIXES)
        // -----------------------------------
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ReservationDto>>> GetReservations()
        {
            foreach (var claim in User.Claims)
            {
                _logger.LogInformation($"Claim Type: {claim.Type}, Value: {claim.Value}");
            }
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdClaim, out int userId))
            {
                _logger.LogError("User ID is null or invalid.");
                return Unauthorized(new { message = "User authentication failed." });
            }

            bool isAdmin = User.IsInRole("Admin");

            var query = _context.Reservations
                .Include(r => r.Flight)
                .Include(r => r.SeatBookings)
                .AsQueryable();

            if (!isAdmin)
            {
                query = query.Where(r => r.UserId == userId);
            }

            var reservations = await query.ToListAsync();

            return reservations.Select(r => new ReservationDto
            {
                Id = r.Id,
                FlightId = r.FlightId,
                ReservationDate = r.ReservationDate,
                Status = r.Status.ToString(),
                TotalAmount = r.TotalAmount,
                SeatBookings = r.SeatBookings.Select(sb => new SeatBookingDto
                {
                    Id = sb.Id,
                    SeatNumber = sb.SeatNumber,
                    SeatClass = sb.SeatClass.ToString(),
                    Price = sb.Price,
                    PassengerName = sb.PassengerName
                }).ToList(),
                Flight = new FlightDto
                {
                    Id = r.Flight.Id,
                    FlightNumber = r.Flight.FlightNumber,
                    AirlineName = r.Flight.AirlineName,
                    DepartureCity = r.Flight.DepartureCity,
                    ArrivalCity = r.Flight.ArrivalCity,
                    DepartureTime = r.Flight.DepartureTime,
                    ArrivalTime = r.Flight.ArrivalTime,
                    AvailableBusinessSeats = r.Flight.AvailableBusinessSeats,
                    AvailableEconomySeats = r.Flight.AvailableEconomySeats,
                    BusinessClassPrice = r.Flight.BusinessClassPrice,
                    EconomyClassPrice = r.Flight.EconomyClassPrice
                }
            }).ToList();
        }

        // -----------------------------------
        // GET SINGLE RESERVATION (WITH FIXES)
        // -----------------------------------
        [HttpGet("{id}")]
        public async Task<ActionResult<ReservationDto>> GetReservation(int id)
        {
            if (!int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out int userId))
            {
                _logger.LogError("User ID is null or invalid.");
                return Unauthorized(new { message = "User authentication failed." });
            }

            bool isAdmin = User.IsInRole("Admin");

            var reservation = await _context.Reservations
                .Include(r => r.Flight)
                .Include(r => r.SeatBookings)
                .FirstOrDefaultAsync(r => r.Id == id);

            if (reservation == null)
            {
                return NotFound(new { message = "Reservation not found." });
            }

            if (!isAdmin && reservation.UserId != userId)
            {
                return Forbid();
            }

            return new ReservationDto
            {
                Id = reservation.Id,
                FlightId = reservation.FlightId,
                ReservationDate = reservation.ReservationDate,
                Status = reservation.Status.ToString(),
                TotalAmount = reservation.TotalAmount,
                SeatBookings = reservation.SeatBookings.Select(sb => new SeatBookingDto
                {
                    Id = sb.Id,
                    SeatNumber = sb.SeatNumber,
                    SeatClass = sb.SeatClass.ToString(),
                    Price = sb.Price,
                    PassengerName = sb.PassengerName
                }).ToList(),
                Flight = new FlightDto
                {
                    Id = reservation.Flight.Id,
                    FlightNumber = reservation.Flight.FlightNumber,
                    AirlineName = reservation.Flight.AirlineName,
                    DepartureCity = reservation.Flight.DepartureCity,
                    ArrivalCity = reservation.Flight.ArrivalCity,
                    DepartureTime = reservation.Flight.DepartureTime,
                    ArrivalTime = reservation.Flight.ArrivalTime,
                    AvailableBusinessSeats = reservation.Flight.AvailableBusinessSeats,
                    AvailableEconomySeats = reservation.Flight.AvailableEconomySeats,
                    BusinessClassPrice = reservation.Flight.BusinessClassPrice,
                    EconomyClassPrice = reservation.Flight.EconomyClassPrice
                }
            };
        }

        // -----------------------------------
        // CREATE RESERVATION (WITH FIXES)
        // -----------------------------------
        [HttpPost]
        public async Task<ActionResult<ReservationDto>> CreateReservation(CreateReservationDto createReservationDto)
        {
            if (!int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out int userId))
            {
                _logger.LogError("User ID is null or invalid.");
                return Unauthorized(new { message = "User authentication failed." });
            }

            if (createReservationDto.FlightId <= 0)
            {
                _logger.LogError("Flight ID is missing or invalid.");
                return BadRequest(new { message = "Flight ID must be provided and valid." });
            }

            var flight = await _context.Flights
                .FirstOrDefaultAsync(f => f.Id == createReservationDto.FlightId && f.IsActive);

            if (flight == null)
            {
                return BadRequest(new { message = "Flight not found or inactive." });
            }

            int businessSeatsRequested = createReservationDto.SeatBookings.Count(sb => sb.SeatClass.ToLower() == "business");
            int economySeatsRequested = createReservationDto.SeatBookings.Count(sb => sb.SeatClass.ToLower() == "economy");

            if (flight.AvailableBusinessSeats < businessSeatsRequested)
            {
                return BadRequest(new { message = "Not enough business class seats available." });
            }

            if (flight.AvailableEconomySeats < economySeatsRequested)
            {
                return BadRequest(new { message = "Not enough economy class seats available." });
            }

            decimal totalAmount = (businessSeatsRequested * flight.BusinessClassPrice) +
                                  (economySeatsRequested * flight.EconomyClassPrice);

            var reservation = new Reservation
            {
                FlightId = flight.Id,
                UserId = userId,
                ReservationDate = DateTime.UtcNow,
                Status = ReservationStatus.Pending,
                TotalAmount = totalAmount
            };

            _context.Reservations.Add(reservation);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetReservation), new { id = reservation.Id }, reservation);
        }
    }
}