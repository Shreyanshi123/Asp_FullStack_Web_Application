﻿//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;

//namespace WebApplication1.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class AuthController : ControllerBase
//    {
//    }
//}

using Microsoft.AspNetCore.Mvc;
using WebApplication1.Repository.User_Repo;
//using WebApplication1.DTOs;
using System.Threading.Tasks;
using WebApplication1.Models.User_Model_;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterUserDto registerDto)
        {
            try
            {
                var userDto = await _authService.RegisterUser(registerDto);
                var token = _authService.GenerateJwtToken(new WebApplication1.Models.User_Model_.User
                {
                    Id = userDto.Id,
                    Username = userDto.Username,
                    Email = userDto.Email,
                    Role = userDto.Role
                });

                return Ok(new { user = userDto, token });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDto loginDto)
        {
            var userDto = await _authService.AuthenticateUser(loginDto);
            if (userDto == null)
                return Unauthorized(new { message = "Invalid username or password" });

            var token = _authService.GenerateJwtToken(new WebApplication1.Models.User_Model_.User
            {
                Id = userDto.Id,
                Username = userDto.Username,
                Email = userDto.Email,
                Role = userDto.Role
            });

            return Ok(new { user = userDto, token });
        }
    }
}


