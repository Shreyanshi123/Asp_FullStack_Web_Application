﻿using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.DataAccessLayer;
using WebApplication1.Models.Payment_Model_;
using WebApplication1.Models.Reservation_Model_;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public PaymentsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<IEnumerable<PaymentDto>>> GetPayments()
        {
            var payments = await _context.Payments
                .Include(p => p.Reservation)
                .ToListAsync();

            return payments.Select(p => new PaymentDto
            {
                Id = p.Id,
                ReservationId = p.ReservationId,
                Amount = p.Amount,
                PaymentDate = p.PaymentDate,
                TransactionId = p.TransactionId,
                Status = p.Status.ToString(),
                PaymentMethod = p.PaymentMethod
            }).ToList();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<PaymentDto>> GetPayment(int id)
        {
            int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            bool isAdmin = User.IsInRole("Admin");

            var payment = await _context.Payments
                .Include(p => p.Reservation)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (payment == null)
            {
                return NotFound();
            }

            // Check if the user is authorized to see this payment
            if (!isAdmin && payment.Reservation.UserId != userId)
            {
                return Forbid();
            }

            return new PaymentDto
            {
                Id = payment.Id,
                ReservationId = payment.ReservationId,
                Amount = payment.Amount,
                PaymentDate = payment.PaymentDate,
                TransactionId = payment.TransactionId,
                Status = payment.Status.ToString(),
                PaymentMethod = payment.PaymentMethod
            };
        }

        [HttpPost]
        public async Task<ActionResult<PaymentDto>> CreatePayment(CreatePaymentDto createPaymentDto)
        {
            int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            bool isAdmin = User.IsInRole("Admin");

            // Check if reservation exists
            var reservation = await _context.Reservations
                .Include(r => r.Payment)
                .FirstOrDefaultAsync(r => r.Id == createPaymentDto.ReservationId);

            if (reservation == null)
            {
                return BadRequest(new { message = "Reservation not found" });
            }

            // Check if the user is authorized to pay for this reservation
            if (!isAdmin && reservation.UserId != userId)
            {
                return Forbid();
            }

            // Check if payment already exists
            if (reservation.Payment != null)
            {
                return BadRequest(new { message = "Payment already exists for this reservation" });
            }

            // Check if reservation is in a payable state
            if (reservation.Status != ReservationStatus.Pending)
            {
                return BadRequest(new { message = $"Cannot process payment for reservation in {reservation.Status} state" });
            }

            // In a real system, you would integrate with a payment gateway here
            // For now, we'll simulate a successful payment

            // Generate a random transaction ID
            string transactionId = Guid.NewGuid().ToString("N");

            // Create the payment
            var payment = new Payment
            {
                ReservationId = reservation.Id,
                Amount = reservation.TotalAmount,
                PaymentDate = DateTime.UtcNow,
                TransactionId = transactionId,
                Status = PaymentStatus.Completed,
                PaymentMethod = createPaymentDto.PaymentMethod
            };

            using var transaction = await _context.Database.BeginTransactionAsync();

            try
            {
                _context.Payments.Add(payment);

                // Update reservation status
                reservation.Status = ReservationStatus.Confirmed;

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                return CreatedAtAction(
                    nameof(GetPayment),
                    new { id = payment.Id },
                    new PaymentDto
                    {
                        Id = payment.Id,
                        ReservationId = payment.ReservationId,
                        Amount = payment.Amount,
                        PaymentDate = payment.PaymentDate,
                        TransactionId = payment.TransactionId,
                        Status = payment.Status.ToString(),
                        PaymentMethod = payment.PaymentMethod
                    }
                );
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return StatusCode(500, new { message = $"Internal server error: {ex.Message}" });
            }
        }

    }
}
