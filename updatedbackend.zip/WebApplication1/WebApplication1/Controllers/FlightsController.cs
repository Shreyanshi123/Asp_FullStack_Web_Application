﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.DataAccessLayer;
using WebApplication1.Models.Flight_Model_;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public FlightsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<FlightDto>>> GetFlights(
            [FromQuery] string departureCity = null,
            [FromQuery] string arrivalCity = null,
            [FromQuery] DateTime? departureDate = null)
        {
            var query = _context.Flights
                .Where(f => f.IsActive)
                .AsQueryable();

            if (!string.IsNullOrEmpty(departureCity))
            {
                query = query.Where(f => f.DepartureCity.ToLower().Contains(departureCity.ToLower()));
            }

            if (!string.IsNullOrEmpty(arrivalCity))
            {
                query = query.Where(f => f.ArrivalCity.ToLower().Contains(arrivalCity.ToLower()));
            }

            if (departureDate.HasValue)
            {
                var date = departureDate.Value.Date;
                query = query.Where(f => f.DepartureTime.Date == date);
            }

            var flights = await query.ToListAsync();

            return flights.Select(f => new FlightDto
            {
                Id = f.Id,
                FlightNumber = f.FlightNumber,
                AirlineName = f.AirlineName,
                DepartureCity = f.DepartureCity,
                ArrivalCity = f.ArrivalCity,
                DepartureTime = f.DepartureTime,
                ArrivalTime = f.ArrivalTime,
                AvailableBusinessSeats = f.AvailableBusinessSeats,
                AvailableEconomySeats = f.AvailableEconomySeats,
                BusinessClassPrice = f.BusinessClassPrice,
                EconomyClassPrice = f.EconomyClassPrice
            }).ToList();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<FlightDto>> GetFlight(int id)
        {
            var flight = await _context.Flights.FindAsync(id);

            if (flight == null || !flight.IsActive)
            {
                return NotFound();
            }

            return new FlightDto
            {
                Id = flight.Id,
                FlightNumber = flight.FlightNumber,
                AirlineName = flight.AirlineName,
                DepartureCity = flight.DepartureCity,
                ArrivalCity = flight.ArrivalCity,
                DepartureTime = flight.DepartureTime,
                ArrivalTime = flight.ArrivalTime,
                AvailableBusinessSeats = flight.AvailableBusinessSeats,
                AvailableEconomySeats = flight.AvailableEconomySeats,
                BusinessClassPrice = flight.BusinessClassPrice,
                EconomyClassPrice = flight.EconomyClassPrice
            };
        }

        [HttpPost]
        //[Authorize(Roles = "Admin")]
        public async Task<ActionResult<FlightDto>> CreateFlight(CreateFlightDto createFlightDto)
        {
            var flight = new Flight
            {
                FlightNumber = createFlightDto.FlightNumber,
                AirlineName = createFlightDto.AirlineName,
                DepartureCity = createFlightDto.DepartureCity,
                ArrivalCity = createFlightDto.ArrivalCity,
                DepartureTime = createFlightDto.DepartureTime,
                ArrivalTime = createFlightDto.ArrivalTime,
                TotalBusinessSeats = createFlightDto.TotalBusinessSeats,
                TotalEconomySeats = createFlightDto.TotalEconomySeats,
                AvailableBusinessSeats = createFlightDto.TotalBusinessSeats,  // Initially all seats are available
                AvailableEconomySeats = createFlightDto.TotalEconomySeats,
                BusinessClassPrice = createFlightDto.BusinessClassPrice,
                EconomyClassPrice = createFlightDto.EconomyClassPrice,
                IsActive = true
            };

            _context.Flights.Add(flight);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetFlight), new { id = flight.Id }, new FlightDto
            {
                Id = flight.Id,
                FlightNumber = flight.FlightNumber,
                AirlineName = flight.AirlineName,
                DepartureCity = flight.DepartureCity,
                ArrivalCity = flight.ArrivalCity,
                DepartureTime = flight.DepartureTime,
                ArrivalTime = flight.ArrivalTime,
                AvailableBusinessSeats = flight.AvailableBusinessSeats,
                AvailableEconomySeats = flight.AvailableEconomySeats,
                BusinessClassPrice = flight.BusinessClassPrice,
                EconomyClassPrice = flight.EconomyClassPrice
            });
        }

        [HttpPut("{id}")]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateFlight(int id, UpdateFlightDto updateFlightDto)
        {
            var flight = await _context.Flights.FindAsync(id);
            if (flight == null || !flight.IsActive)
            {
                return NotFound();
            }

            flight.FlightNumber = updateFlightDto.FlightNumber;
            flight.AirlineName = updateFlightDto.AirlineName;
            flight.DepartureCity = updateFlightDto.DepartureCity;
            flight.ArrivalCity = updateFlightDto.ArrivalCity;
            flight.DepartureTime = updateFlightDto.DepartureTime;
            flight.ArrivalTime = updateFlightDto.ArrivalTime;
            flight.BusinessClassPrice = updateFlightDto.BusinessClassPrice;
            flight.EconomyClassPrice = updateFlightDto.EconomyClassPrice;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FlightExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteFlight(int id)
        {
            var flight = await _context.Flights.FindAsync(id);
            if (flight == null)
            {
                return NotFound();
            }

            // Soft delete
            flight.IsActive = false;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool FlightExists(int id)
        {
            return _context.Flights.Any(e => e.Id == id);
        }

    }
}
