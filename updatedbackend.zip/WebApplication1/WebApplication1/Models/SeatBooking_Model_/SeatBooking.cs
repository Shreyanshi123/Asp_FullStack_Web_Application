﻿using WebApplication1.Models.Reservation_Model_;

namespace WebApplication1.Models.SeatBooking_Model_
{
    public enum SeatClass
    {
        Business,
        Economy
    }

    public class SeatBooking
    {
        public int Id { get; set; }
        public int ReservationId { get; set; }
        public string? SeatNumber { get; set; }
        public SeatClass SeatClass { get; set; }
        public decimal Price { get; set; }
        public string? PassengerName { get; set; }

        public virtual Reservation? Reservation { get; set; }

    }
}
