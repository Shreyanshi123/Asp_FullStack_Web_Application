import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import {jwtDecode} from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  
  private API_URL = 'https://localhost:7044/api';
  constructor(private http: HttpClient) { }

  signUp(user: any): Observable<any> {
    return this.http.post(`${this.API_URL}/Auth/register`, user);
  }

  signIn(user: any): Observable<any> {
    return this.http.post(`${this.API_URL}/Auth/login`, user);
  }
  signOut() {
    localStorage.removeItem('token');
  }

  getToken(){
    return localStorage.getItem('token');
  }

  dataFromToken(){
    const token = this.getToken();
    if(token){
      var decodedToken = jwtDecode(token) as{
        "role": string;};
        var userRole = decodedToken["role"];
        return userRole;
      }
      else{
        return "";
      }
      }
    }
 
