import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable ,throwError} from 'rxjs';
import { tap,catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FlightsService {
  private baseUrl = 'https://localhost:7044/api/Flights';
  constructor(private http:HttpClient) { }

  searchFlight(from: string, to: string, departureDate: string): Observable<any> {
    // Ensure the date format matches backend expectations
    // const formattedDate = departureDate.split("T")[0];

    const params = new HttpParams()
      .set('departureCity', from)
      .set('arrivalCity', to)
      .set('departureDate', departureDate);

    console.log("Requesting flights from:", `${this.baseUrl}`);
    console.log("Params:", params.toString());
    const requestUrl = `${this.baseUrl}?${params.toString()}`;


    return this.http.get(requestUrl).pipe(
      tap(response => {
        console.log("API Response in FlightService:", response);
      }),
      catchError(error => {
        console.error("API Call Failed:", error);
        return throwError(error);
      })
    );
  }

  getFlights(){
    return this.http.get(`${this.baseUrl}`);
  }

  deleteFlights(flightNumber:any){
     const headers = new HttpHeaders().set('Authorization', 'Bearer ' + localStorage.getItem('token'));
    console.log(flightNumber);
    return this.http.delete(`${this.baseUrl}/${flightNumber}`,{headers});
  }
  
  getFlightByFlightNumber(flightNumber:any){
    console.log(flightNumber);
    return this.http.get(`${this.baseUrl}/${flightNumber}`);
  }

  updateFlight(FlightNumber:string,FlightData:any){
    FlightData= JSON.stringify(FlightData);
    console.log(FlightData);
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token'),
      'Content-Type': 'application/json'
    });
    return this.http.put(`${this.baseUrl}/${FlightNumber}`,FlightData,{headers,responseType:'text'});
  }

  addFlights(FlightData:any){
    const headers = new HttpHeaders().set('Authorization', 'Bearer ' + localStorage.getItem('token'));
    console.log(FlightData);
    return this.http.post(`${this.baseUrl}/`,FlightData,{headers});
  }

}
