import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient,HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private API_URL = 'https://localhost:7044/api/Reservations';
  constructor(private http: HttpClient) { }

  getBookingInformation(flightId:number){
     const token = localStorage.getItem("token");
     const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
    return this.http.get(`${this.API_URL}/${flightId}`,{headers});
  }
  bookTickets(flightNumber:number,data:any[]){
    const token = localStorage.getItem("token");
     const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });

    console.log(headers);
    const payload = {
      flightId:flightNumber,
      seatBookings: data.map(traveller=>({
        seatClass : traveller.firstName,
         passengerName :traveller.firstName+''+traveller.lastName
      }))
    };
    return this.http.post(`${this.API_URL}`,payload,{headers});
  }
}
