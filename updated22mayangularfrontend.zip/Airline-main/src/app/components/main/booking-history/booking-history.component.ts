import { Component, inject } from '@angular/core';
import { BookingService } from '../../../services/booking.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-booking-history',
  imports:[CommonModule],
  templateUrl: './booking-history.component.html',
  styleUrls: ['./booking-history.component.css']
})
export class BookingHistoryComponent {
  bookingService = inject(BookingService);
  bookingList: any[] = [];

  ngOnInit() {
    // this.fetchBookingHistory();
  }

  // fetchBookingHistory() {
  //   this.bookingService.getUserBookings().subscribe({
  //     next: (data: any) => {
  //       this.bookingList = data;
  //     },
  //     error: (err) => {
  //       console.log("Error fetching booking history:", err);
  //     }
  //   });
  // }
}
