import { Component, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookingService } from '../../../services/booking.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-booking-confirmation',
  imports:[CommonModule],
  templateUrl: './booking-confirmation.component.html',
  styleUrls: ['./booking-confirmation.component.css']
})
export class BookingConfirmationComponent {
  flightDetails: any;
  travellerList: any[] = [];
  FlightId:any;

  route = inject(ActivatedRoute);
  bookingService = inject(BookingService);
  router = inject(Router);

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.FlightId = params['flightId'];
      this.bookingService.getBookingInformation(this.FlightId).subscribe({
        next: (data: any) => {
          console.log(data);
          this.flightDetails = data.flight;
          // this.travellerList = data.travellers;
        },
        error: (err) => {
          console.log(err);
        }
      });
    });
  }

  proceedToPayment() {
    this.router.navigate(['/payment']);
  }
}