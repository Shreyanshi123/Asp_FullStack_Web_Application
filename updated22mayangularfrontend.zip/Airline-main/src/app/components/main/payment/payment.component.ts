import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment',
  imports:[CommonModule,FormsModule],
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent {
  totalAmount: number = 5000; // Example amount
  selectedPaymentMethod: string = '';

  constructor(private router: Router) {}

  processPayment() {
    if (!this.selectedPaymentMethod) {
      alert("Please select a payment method.");
      return;
    }

    alert(`Payment successful via ${this.selectedPaymentMethod}. Redirecting...`);
    this.router.navigate(['/payment-success']);
  }
}
