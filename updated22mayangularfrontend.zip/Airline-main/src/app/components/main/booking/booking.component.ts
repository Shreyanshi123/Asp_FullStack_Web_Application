import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FlightsService } from '../../../services/flights.service';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { BookingService } from '../../../services/booking.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-booking',
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './booking.component.html',
  styleUrl: './booking.component.css'
})
export class BookingComponent {
  travellerList:any[] =[];
  flightDetails:any;
  tripDetails:any;
  flightNumber:any;
  flightService = inject(FlightsService)
  route = inject(ActivatedRoute);
  router = inject(Router);
  bookingService = inject(BookingService);
  bookingId:any;

  travellerForm :FormGroup;
  constructor(){
    this.travellerForm = new FormGroup({
      firstName: new FormControl('',Validators.required),
      lastName: new FormControl('',Validators.required),
      seatClass: new FormControl('Economy')
    })
  }
  ngOnInit(): void {
    this.travellerList=[];
      this.route.params.subscribe(params=>{
        this.flightNumber=params['flightNumber'];

        this.flightService.getFlightByFlightNumber(this.flightNumber).subscribe({
            next:(data:any)=>{
              console.log(data);
             this.flightDetails = data;
             console.log(this.flightDetails);
            },
            error:(err)=>{
              console.log(err);
            }
        })
      })
    }

  addTraveller(){
    if(this.travellerForm.invalid){
      return;
    }
    const newTraveller ={
    firstName: this.travellerForm.get('firstName')?.value,
    lastName: this.travellerForm.get('lastName')?.value,
    seatClass: this.travellerForm.get('seatClass')?.value,
    }
     console.log("New Traveller Added:", newTraveller); 
    this.travellerList.push(newTraveller);

    this.travellerForm.reset();
  }

  ProceedToBooking(){
    console.log(this.travellerList);
    this.bookingService.bookTickets(this.flightNumber,this.travellerList)
    .subscribe({
      next:(data:any)=>{
        console.log(data);
        this.bookingId = data.id;
        Swal.fire({
        title: 'Booking Confirmed!',
        text: 'Redirecting to the confirmation page...',
        icon: 'success',
        timer: 2000,
        showConfirmButton: false
      }).then(() => {
        this.router.navigate(['/booking-confirmation', this.bookingId]); // Redirect after alert
      });
      },

      error:(err)=>{
        console.log(err);
      }
    })
  }
}
