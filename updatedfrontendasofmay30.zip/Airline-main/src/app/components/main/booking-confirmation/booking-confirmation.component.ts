import { Component, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookingService } from '../../../services/booking.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-booking-confirmation',
  imports:[CommonModule],
  templateUrl: './booking-confirmation.component.html',
  styleUrls: ['./booking-confirmation.component.css']
})
export class BookingConfirmationComponent {
  flightDetails: any;
  travellerList: any[] = [];
  FlightId:any;
  bookingId:any;
  id:any;
  totalAmount :any;
  route = inject(ActivatedRoute);
  bookingService = inject(BookingService);
  router = inject(Router);
  getSeatClassLabel(value: number): string {
  const seatClassMap: Record<number, string> = {
    0: 'Economy',
    1: 'Business'
  };
  return seatClassMap[value] || 'Unknown'; // Handle unexpected values
}
calculateTotalFare(): number {
  return this.travellerList.reduce((total, traveller) => total + traveller.price, 0);
}

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.FlightId = params['flightId'];
      this.bookingService.getBookingInformation(this.FlightId).subscribe({
        next: (data: any) => {
          console.log(data);
          this.id= data.id;
          this.bookingId = data.bookingReference;
          console.log(this.bookingId);
          this.flightDetails = data.flight;
          this.travellerList = data.passengers;
          this.totalAmount = data.totalAmount
        },
        error: (err) => {
          console.log(err);
        }
      });
    });
  }

  proceedToPayment() {
    this.router.navigate(['/payment',this.id]);
  }
}