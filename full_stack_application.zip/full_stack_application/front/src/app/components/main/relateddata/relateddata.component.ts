import { Component } from '@angular/core';

@Component({
  selector: 'app-relateddata',
  imports: [],
  templateUrl: './relateddata.component.html',
  styleUrl: './relateddata.component.css'
})
export class RelateddataComponent {

}
