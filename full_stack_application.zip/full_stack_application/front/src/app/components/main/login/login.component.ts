import { Component, inject } from '@angular/core';
import { FormControl,FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { jwtDecode } from 'jwt-decode';
@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  authService = inject(AuthService);
 constructor(private router:Router){};
 formData:FormGroup= new FormGroup({
  emailId:new FormControl('',Validators.required),
    password:new FormControl('',[Validators.required]),
    
})
 loginControl(): void {
  // Add logic to validate user credentials here
  let myFormData = this.formData.value;
    console.log(this.formData.value);
    this.authService.signIn(myFormData)
      .subscribe({
        next:(data:any)=>{
          var token = data.token;
          // localstorage save
          localStorage.setItem("_token",token);
          // var decodedToken = jwtDecode(token) as { 
          //   "http://schemas.microsoft.com/ws/2008/06/identity/claims/role": string;};
          // var userRole = decodedToken["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];
          // console.log(userRole);
          //token generated
          // claimtype role 
          if(this.authService.dataFromToken()=="user"){
            this.router.navigate(['/home']);
          }
          if(this.authService.dataFromToken()=="Admin"){
            this.router.navigate(['/dashboard'])
          }
          // else {
          //   console.error('Login failed:', data.msg);
          // }
        },
        error:(err:any)=>{
          console.log(err);
        }
      })
  // Navigate to the dashboard
  // this.router.navigate(['/dashboard/dashboard']);
}

}
