import { Component } from '@angular/core';

@Component({
  selector: 'app-footer-main',
  imports: [],
  templateUrl: './footer-main.component.html',
  styleUrl: './footer-main.component.css'
})
export class FooterMainComponent {

}
