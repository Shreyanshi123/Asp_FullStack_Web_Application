import { Component, inject, OnInit } from '@angular/core';
import { ReactiveFormsModule,FormControl,FormGroup, FormBuilder } from '@angular/forms';
import { ProductService } from '../../../services/product.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-product',
  imports: [ReactiveFormsModule],
  templateUrl: './edit-product.component.html',
  styleUrl: './edit-product.component.css'
})
export class EditProductComponent implements OnInit {
  productId!:number;
  router = inject(Router)
  productService = inject(ProductService)
  activatedRoute = inject(ActivatedRoute)
  productForm = new FormGroup({
    Id: new FormControl(),
    Category:new FormControl(),
    PName : new FormControl(),
    Price: new FormControl(),
    Quantity:new FormControl(),
    Features : new FormControl(),
    ProfilePicture:new FormControl(),
    FileSource: new FormControl()

  });

  onFileChange(event: any) {
    const file = event.target.files[0];
    this.productForm.patchValue({
      FileSource:file,
    });
  }
  ngOnInit(): void {
    this.productId = +this.activatedRoute.snapshot.paramMap.get('id')!;
    console.log('Product ID from URL:', this.productId);
    this.productService.getProductByID(this.productId)
        .subscribe({
          next:(product:any)=>{
              console.log(product.product);
              this.productForm.patchValue({
                Id:product.product.id,
                PName:product.product.pName,
                Category:product.product.category,
                Features:product.product.features,
                Price:product.product.price,
                Quantity:product.product.quantity,
              })
              console.log(this.productForm.value)
              
          },
          error:(err)=>{
            console.log(err)
          }
        })
    
  }
  //get the product from using the id
submitHandler(){
  const formData = new FormData();
      formData.append('ProfilePicture', this.productForm.get('FileSource')?.value);
      formData.append('Id', this.productForm.get("Id")?.value);
      formData.append('Category', this.productForm.get("Category")?.value);
      formData.append('PName', this.productForm.get("PName")?.value);
      formData.append('Price', this.productForm.get("Price")?.value);
      formData.append('Quantity', this.productForm.get("Quantity")?.value);
      formData.append('Features', this.productForm.get("Features")?.value);

      formData.forEach((value, key) => {
        console.log(`${key}:`, value);
      });
      

  this.productService.editProduct(this.productId,formData)
    .subscribe({
      next:(data:any)=>{
        console.log(data);
        this.router.navigateByUrl("/dashboard")
      },
      error:(err)=>{
        console.log(err);
      }
    })
}

}
