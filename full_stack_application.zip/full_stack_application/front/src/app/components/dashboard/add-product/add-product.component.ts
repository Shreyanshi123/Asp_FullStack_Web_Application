import { Component, inject } from '@angular/core';
import { FormGroup, 
 FormControl, ReactiveFormsModule } from '@angular/forms';
import { ProductService } from '../../../services/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  imports: [ReactiveFormsModule],
  templateUrl: './add-product.component.html',
  styleUrl: './add-product.component.css'
})
export class AddProductComponent {
    productService = inject(ProductService);
    router = inject(Router)
    productForm = new FormGroup({
      Id: new FormControl(),
      Category:new FormControl(),
      PName : new FormControl(),
      PPrice: new FormControl(),
      Quantity:new FormControl(),
      Features : new FormControl(),
      ProfilePicture:new FormControl(),
      FileSource: new FormControl()

    });

    onFileChange(event: any) {
      const file = event.target.files[0];
      this.productForm.patchValue({
        FileSource:file,
      });
    }
    
    AddProduct(){
      const token = localStorage.getItem("_token");
      const formData = new FormData();
      formData.append('ProfilePicture', this.productForm.get('FileSource')?.value);
      formData.append('Id', this.productForm.get("Id")?.value);
      formData.append('Category', this.productForm.get("Category")?.value);
      formData.append('PName', this.productForm.get("PName")?.value);
      formData.append('PPrice', this.productForm.get("PPrice")?.value);
      formData.append('Quantity', this.productForm.get("Quantity")?.value);
      formData.append('Features', this.productForm.get("Features")?.value);
      console.log(formData);
      this.productService.addProduct(formData)
          .subscribe({
            next:(data)=>{
              console.log(data);
              this.router.navigateByUrl("/dashboard")
            },
            error:(err)=>{
              console.log(err);
            }
          })
    
    }
}
