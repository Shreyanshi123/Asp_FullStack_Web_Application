import { Component, Inject, inject, OnInit } from '@angular/core';
import { ProductService } from '../../../services/product.service';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dash-home',
  imports: [CommonModule],
  templateUrl: './dash-home.component.html',
  styleUrl: './dash-home.component.css'
})
export class DashHomeComponent implements OnInit{
productService = inject(ProductService);
constructor(private router:Router){};
formData:any;

  ngOnInit(): void {
  this.productService.getProduct()
    .subscribe({
      next:(data:any)=>{
        console.log(data);
        console.log(data.product[0].picturePath);
        this.formData = data.product;
      },
      error:(err)=>{
        console.log(err);
      }
    })
  }
  deleteHandler(id:any){
      this.productService.deleteProduct(id)
      .subscribe({
        next: (response) => {
          console.log('Product deleted successfully:', response);
          // Update the local formData to remove the deleted product
          this.formData = this.formData.filter((product: any) => product.id !== id);
        },
        error: (err) => {
          console.error('Error deleting product:', err);
        }
      });
  }
  editHandler(id:any){
   
     
    
    this.router.navigate(['/dashboard/editProduct', id])

       
   
  }
}
