import { Routes } from '@angular/router';
import { MainComponent } from './components/main/main.component';
import { AboutComponent } from './components/main/about/about.component';
import { LoginComponent } from './components/main/login/login.component';
import { RegisterComponent } from './components/main/register/register.component';
import { HomeComponent } from './components/main/home/home.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AddProductComponent } from './components/dashboard/add-product/add-product.component';
import { DashHomeComponent } from './components/dashboard/dash-home/dash-home.component';
import { EditProductComponent } from './components/dashboard/edit-product/edit-product.component';
import { authGuard } from './guards/auth.guard';
export const routes: Routes = [
    {path:"",component:MainComponent,children:[
        {path:"home",component:HomeComponent},
        {path:"about",component:AboutComponent},
        {path:"login",component:LoginComponent},
        {path:"register",component:RegisterComponent}
    ]},
    {path: 'dashboard', component: DashboardComponent,canActivate:[authGuard],children:[{
        path:"",component:DashHomeComponent},
        {path:"addProduct",component:AddProductComponent},
        {path:'editProduct/:id',component:EditProductComponent}]}
];
