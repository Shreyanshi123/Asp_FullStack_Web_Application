import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { jwtDecode } from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private API_URL ="https://localhost:7288";
  constructor(private http:HttpClient) { }

  signUp(data:any){
    return this.http.post(`${this.API_URL}/api/Registration`,data);
  }
  signIn(data:any){
    return this.http.post(`${this.API_URL}/api/Login/Login`,data);
  }
  signOut(){
    localStorage.removeItem("_token");
  }
  getToken(){
    return localStorage.getItem("_token");
  }
  dataFromToken(){
    var token = this.getToken();
      if(token){
        var decodedToken = jwtDecode(token) as { 
          "http://schemas.microsoft.com/ws/2008/06/identity/claims/role": string;};
        var userRole = decodedToken["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];
        return userRole;
      }
      else{
        return "";
      }
  }
}
