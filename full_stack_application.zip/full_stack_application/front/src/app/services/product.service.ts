import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private API_URL ="https://localhost:7288";

  constructor(private http:HttpClient) { };

  addProduct(data:any){
    const headers = new HttpHeaders().set('Authorization',`Bearer ${localStorage.getItem('_token')}`);
    return this.http.post(`${this.API_URL}/api/Product`,data,{headers});
  }
  getProduct(){
    return this.http.get(`${this.API_URL}/api/Product`);
  }
  getProductByID(id:number){
    return this.http.get(`${this.API_URL}/api/Product/${id}`);
  }
  deleteProduct(id:any){
    const headers = new HttpHeaders().set('Authorization',`Bearer ${localStorage.getItem('_token')}`);
    return this.http.delete(`${this.API_URL}/api/Product/${id}`,{headers})
  }
  editProduct(id:number,product:any){
    const headers = new HttpHeaders().set('Authorization',`Bearer ${localStorage.getItem('_token')}`);
    console.log('Authorization header:', headers.get('Authorization'));
    return this.http.put(`${this.API_URL}/api/Product/${id}`,product,{headers})
  }
}
