﻿using System.Text;
using AutoMapper;
using backend.DataAccessLayer;
using backend.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace backend.RegistrationRepository
{
    public class RegistrationRepo:IRegistrationRepository
    {
        private readonly ProductDBContext productDBContext;
        private readonly IMapper mapper;
        public RegistrationRepo(ProductDBContext productDBContext, IMapper mapper)
        {
            this.productDBContext = productDBContext;
            this.mapper = mapper;
        }

        public async Task<RegistrationModel> UpdateUserRole(string email,string role)
        {
            var users = await productDBContext.Registration.Where(x => x.EmailId == email).FirstOrDefaultAsync();
            if (users.EmailId != null)
            {
                users.Roles = role;

                await productDBContext.SaveChangesAsync();
                return users;

            }
            return new RegistrationModel();
        }
       
        public async Task<RegistrationModel> RegisterUser(RegistrationUIModel model)
        {
            var model2 = mapper.Map<RegistrationModel>(model);


            var sha1 = System.Security.Cryptography.SHA1.Create();
            var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(model2.Password));
            model2.Password = Convert.ToBase64String(hash);

            var user = await productDBContext.Registration.Where(x => x.EmailId == model2.EmailId).FirstOrDefaultAsync();
            if (user== null)
            {
                await productDBContext.Registration.AddAsync(model2);
                await productDBContext.SaveChangesAsync();
                return model2;
            }
            else
            {
                return new RegistrationModel();
            }
        }
        public async Task<List<RegistrationModel>> GetAllUser()
        {
            var users = await productDBContext.Registration.ToListAsync();
            return users;
        }

        public async Task<RegistrationModel> GetUserByEmailId(string Email)
        {
            var user = await productDBContext.Registration.Where(x => x.EmailId == Email).FirstOrDefaultAsync();
            if (user == null)
            {
                return new RegistrationModel();
            }
            return user;
        }

        public async Task<string> DeleteUser(string email)
        {
            var user = await productDBContext.Registration.Where(x => x.EmailId == email).FirstOrDefaultAsync();
            if (user == null)
            {
                return "";
            }
            productDBContext.Registration.Remove(user);
            await productDBContext.SaveChangesAsync();
            return user.EmailId;
        }

        public async Task<RegistrationModel> UpdateUser(string email, RegistrationUIModel user)
        {
            var users = await productDBContext.Registration.Where(x => x.EmailId == email).FirstOrDefaultAsync();
            if (users!= null)
            {
                users.EmailId = user.EmailId;
                users.FirstName = user.FirstName;
                users.LastName = user.LastName;
                user.Phone = user.Phone;

                await productDBContext.SaveChangesAsync();
                return users;

            }
            return new RegistrationModel();
        }
    }
}
