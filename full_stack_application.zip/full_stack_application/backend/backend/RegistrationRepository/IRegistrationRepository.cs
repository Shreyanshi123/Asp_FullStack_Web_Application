﻿using backend.Models;

namespace backend.RegistrationRepository
{
    public interface IRegistrationRepository
    {
        Task<RegistrationModel> RegisterUser(RegistrationUIModel user);
        Task<List<RegistrationModel>> GetAllUser();

        Task<RegistrationModel> GetUserByEmailId(string Email);

        Task<string> DeleteUser(string email);
        Task<RegistrationModel> UpdateUserRole(string email, string role);
        Task<RegistrationModel> UpdateUser(string email, RegistrationUIModel user);

    }
}
