﻿using AutoMapper;
using backend.Models;
using backend.ProductRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        

        private IProductRepository productRepository;
        private readonly IMapper mapper;

        public ProductController(IProductRepository productRepository, IMapper mapper)
        {
            this.productRepository = productRepository;
            this.mapper = mapper;
        }

        [HttpPost]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> AddProduct([FromForm] ProductUIModel product)
        {
            if (product.ProfilePicture != null)
            {
                var uploadsFolderPath = Path.Combine(Directory.GetCurrentDirectory(), "Uploads");
                if (!Directory.Exists(uploadsFolderPath))
                {
                    Directory.CreateDirectory(uploadsFolderPath);
                }

                var uniqueFileName = Guid.NewGuid().ToString() + "_" + product.ProfilePicture.FileName;
                var filePath = Path.Combine(uploadsFolderPath, uniqueFileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await product.ProfilePicture.CopyToAsync(stream);
                }
                
                
                var response = mapper.Map<ProductModel>(product);
                response.PicturePath= "/Uploads/" + uniqueFileName;

                await productRepository.AddProduct(response);


                return Ok(new {err=0,msg="Product Added",res=response,id=response.Id});
            }
            return BadRequest("Bad request");
        }


        [HttpGet]

        public async Task<IActionResult> GetAllProduct()
        {
            var res = await productRepository.GetAllProducts();
            return Ok( new { err = 0, msg = "All Products", product = res });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetByID([FromRoute] int id)
        {

            var res = await productRepository.GetProductById(id);
            if (res == null)
            {
                return NotFound();
            }
            return Ok(new{ err = 0, msg = "All Products", product = res });
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteByid([FromRoute] int id)
        {

            int id1 = await productRepository.DeleteProduct(id);
            if (id1 == 0)
            {
                return NotFound("Unable to delete");
            }
            return Ok(new {err=0,msg="Deleted",id=id1});
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateProduct(int id,[FromForm] ProductUIModel product)
        {
          
            int id1 = await productRepository.UpdateProduct(id, product);
            //productModel.PicturePath= 
            if (id1 == 0)
            {
                return NotFound(new { err = 1, msg = "Product unable to update", product = id1 });
            }
            return Ok(new { err = 0, msg = "All Products", product = id1 });
        }
    }
}
