﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using backend.LoginRepository;
using backend.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
       
        private readonly ILoginRepository user;
        private readonly IConfiguration _configuration;

        public LoginController(ILoginRepository user, IConfiguration configuration)
        {
            this.user = user;
            _configuration = configuration;
        }

        [HttpPost("Login")]

        public async Task<IActionResult> Login(LoginModel model)
        {
            string email = model.EmailId;
            string password = model.Password;

            var users = await user.LoginUser(email, password);
            if (users.EmailId == "")
            {
                return Unauthorized(new { err = 1, msg = "Invalid user credentials." });
            }
            else
            {
                var token = IssueToken(users);
                return Ok(new { err = 0, msg = "valid user credentials.", Token = token });
            }
        }
        private string IssueToken(RegistrationModel user)
        {
            // Creates a new symmetric security key from the JWT key specified in the app configuration.
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            // Sets up the signing credentials using the above security key and specifying the HMAC SHA256 algorithm.
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            // Defines a set of claims to be included in the token.
            var claims = new List<Claim>
            {
                new Claim("MyApp_User_Id", user.EmailId),
                new Claim(ClaimTypes.NameIdentifier, user.FirstName+user.LastName),
                new Claim(ClaimTypes.Email, user.EmailId),
                new Claim(ClaimTypes.Role,user.Roles),
                new Claim(JwtRegisteredClaimNames.Sub, user.EmailId),
            };

            // Adds a role claim for each role associated with the user.
            
            // Creates a new JWT token with specified parameters including issuer, audience, claims, expiration time, and signing credentials.
            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddHours(1), // Token expiration set to 1 hour from the current time.
                signingCredentials: credentials);

            // Serializes the JWT token to a string and returns it.
            return new JwtSecurityTokenHandler().WriteToken(token);

        }
    }
}
