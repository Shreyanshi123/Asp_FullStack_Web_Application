﻿using AutoMapper;
using Azure;
using backend.Models;
using backend.RegistrationRepository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationController : ControllerBase
    {

        private readonly IRegistrationRepository registration;
        
        public RegistrationController(IRegistrationRepository registration, IMapper mapper)
        {
            this.registration = registration;
            
        }
        //[HttpPost("{role}")]
        //public async Task<IActionResult> UpdateRole()
        [HttpPost]
        public async Task<IActionResult> AddUser([FromBody] RegistrationUIModel model)
        {
           
            var result = await registration.RegisterUser(model);
            if (!string.IsNullOrEmpty(result.EmailId))
            {
                return Ok(new { err = 0, msg = "Registered User", response = model });
            }
            else
            {
                return BadRequest(new { err = 1, msg = "User already exits or something went wrong", response = model });
            }
        }
        [HttpGet]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllUsers()
        {

            var res = await registration.GetAllUser();
            return Ok(new { err = 0, msg = "All the users are provided", response = res });
        }

        [HttpGet("{email}")]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetByID([FromRoute] string email)
        {

            var res = await registration.GetUserByEmailId(email);
            if (res.EmailId == "")
            {
                return BadRequest(new { err = 1, msg = "Email not found", response = res });
            }
            else
            {
                return Ok(new { err = 0, msg = "Registered User", response = res });
            }
        }

        [HttpDelete("{email}")]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteByid([FromRoute] string email)
        {

            string emailId = await registration.DeleteUser(email);
            if (string.IsNullOrEmpty(emailId))
            {
                return BadRequest(new { err = 1, msg = "Email not found", response = emailId });
            }
            else
            {
                return Ok(new { err = 0, msg = "Registered User", response = emailId });
            }
        }


    }
}
