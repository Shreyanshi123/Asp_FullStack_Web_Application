﻿using AutoMapper;
using backend.Models;

namespace backend.AutoMapper
{
    public class ProductMapping : Profile
    {
        public ProductMapping()
        {
            {
                // Map ProductModel to ProductUIModel
                CreateMap<ProductModel, ProductUIModel>()
                    .ForMember(dest => dest.ProfilePicture, opt => opt.Ignore()); // Ignore ProfilePicture as it's a different type

                // Map ProductUIModel to ProductModel
                CreateMap<ProductUIModel, ProductModel>()
                    .ForMember(dest => dest.PicturePath, opt => opt.Ignore());
            }
        }
    }
}