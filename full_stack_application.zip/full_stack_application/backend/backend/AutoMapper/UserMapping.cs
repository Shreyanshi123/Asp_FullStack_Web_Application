﻿using AutoMapper;
using backend.Models;

namespace backend.AutoMapper
{
    public class UserMapping:Profile
    {
        public UserMapping()
        {
            CreateMap<RegistrationModel, RegistrationUIModel>()
                .ForMember(dest => dest.EmailId, opt => opt.MapFrom(src => src.EmailId))
                .ForMember(dest => dest.Password, opt => opt.MapFrom(src => src.Password))
                .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.FirstName))
                .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.LastName))
                .ForMember(dest => dest.Phone, opt => opt.MapFrom(src => src.Phone))
                .ForMember(dest => dest.Age, opt => opt.MapFrom(src => src.Age))
                .ForSourceMember(src => src.Roles, opt => opt.DoNotValidate()); // Ignore unmapped properties


            CreateMap<RegistrationUIModel, RegistrationModel>()
                .ForMember(dest => dest.EmailId, opt => opt.MapFrom(src => src.EmailId))
                .ForMember(dest => dest.Password, opt => opt.MapFrom(src => src.Password))
                .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.FirstName))
                .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.LastName))
                .ForMember(dest => dest.Phone, opt => opt.MapFrom(src => src.Phone))
                .ForMember(dest => dest.Age, opt => opt.MapFrom(src => src.Age))
                .ForMember(dest => dest.Roles, opt => opt.Ignore());
        }   
    }
}
