﻿using backend.Models;

namespace backend.ProductRepository
{
    public interface IProductRepository
    {
        Task<List<ProductModel>> GetAllProducts();

        Task<ProductModel> GetProductById(int? id);
        Task<int> AddProduct(ProductModel product);

        Task<int> UpdateProduct(int id, ProductUIModel product);
        Task<int> DeleteProduct(int? id);
    }
}
