﻿using AutoMapper;
using Azure;
using backend.DataAccessLayer;
using backend.Models;
using Microsoft.EntityFrameworkCore;

namespace backend.ProductRepository
{
    public class ProductRepo : IProductRepository
    {
        private readonly ProductDBContext productDBContext;
        private readonly IMapper mapper;
        public ProductRepo(ProductDBContext productDBContext, IMapper mapper)
        {
            this.productDBContext = productDBContext;
            this.mapper = mapper;
        }

        public async Task<int> AddProduct(ProductModel product)
        {
            await productDBContext.Products.AddAsync(product);
            await productDBContext.SaveChangesAsync();
            return product.Id;
        }

        public async Task<int> DeleteProduct(int? id)
        {
            var data = productDBContext.Products.Where(x => x.Id == id).First();
            if (data.PName != null)
            {
                productDBContext.Remove(data);
                await productDBContext.SaveChangesAsync();
            }
            return data.Id;
        }

        public async Task<List<ProductModel>> GetAllProducts()
        {
            var productList = await productDBContext.Products.ToListAsync();
            return productList;
        }

        public async Task<ProductModel> GetProductById(int? id)
        {
            var data = await productDBContext.Products.Where(x => x.Id == id).FirstOrDefaultAsync();
            if (data == null)
            {
                return new ProductModel();
            }
            else
            {
                return data;
            }

        }

        public async Task<int> UpdateProduct(int id, ProductUIModel productModel)
        {
            var uploadsFolderPath = Path.Combine(Directory.GetCurrentDirectory(), "Uploads");
            var uniqueFileName = Guid.NewGuid().ToString() + "_" + productModel.ProfilePicture.FileName;
            var filePath = Path.Combine(uploadsFolderPath, uniqueFileName);
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await productModel.ProfilePicture.CopyToAsync(stream);
            }


            var product = mapper.Map<ProductModel>(productModel);
            product.PicturePath = "/Uploads/" + uniqueFileName;

            var data = await productDBContext.Products.Where(x => x.Id == id).FirstOrDefaultAsync();
            if (data != null)
            {
                data.PName = product.PName;
                data.Quantity = product.Quantity;
                data.Price = product.Price;
                data.Features = product.Features;
                data.Category = product.Category;
                data.PicturePath = product.PicturePath;

                
                await productDBContext.SaveChangesAsync();
            }
            return productModel.Id;
        }
    }
}
