﻿using backend.Models;

namespace backend.LoginRepository
{
    public interface ILoginRepository
    {
        Task<RegistrationModel> LoginUser(string email, string password);
    }
}
