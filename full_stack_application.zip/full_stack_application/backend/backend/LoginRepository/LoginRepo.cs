﻿using System.Text;
using backend.DataAccessLayer;
using backend.Models;
using Microsoft.EntityFrameworkCore;

namespace backend.LoginRepository
{
    public class LoginRepo:ILoginRepository
    {
        private readonly ProductDBContext productDBContext;
        public LoginRepo(ProductDBContext productDBContext)
        {
            this.productDBContext = productDBContext;
        }

        public async Task<RegistrationModel> LoginUser(string email, string password)
        {
            var data = await productDBContext.Registration.Where(x => x.EmailId == email).FirstOrDefaultAsync();

            if (data != null)
            {
                var dbPassword = data.Password;
                var sha1 = System.Security.Cryptography.SHA1.Create();
                var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(password));
                password = Convert.ToBase64String(hash);
                if (dbPassword == password)
                {
                    return data;

                }
                else
                {
                    return new RegistrationModel();
                }
            }
            else
            {
                return new RegistrationModel();
            }
        }

    }

}
