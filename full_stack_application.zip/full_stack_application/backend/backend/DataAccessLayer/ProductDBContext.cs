﻿using backend.Models;
using Microsoft.EntityFrameworkCore;

namespace backend.DataAccessLayer
{
    public class ProductDBContext:DbContext
    {
        public ProductDBContext(DbContextOptions<ProductDBContext> options) : base(options)
        {
        }
        public DbSet<ProductModel> Products { get; set; }

        public DbSet<RegistrationModel> Registration { get; set; }


        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<ProductModel>(entity => {
                entity.HasIndex(e => e.PName).IsUnique();
            });
        }
    }
}
