﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace backend.Models
{
    public class ProductUIModel
    {
        [Key]
        public int Id { get; set; }
        public string Category { get; set; }
        public string PName { get; set; } = string.Empty;
        public double Price { get; set; }

        public int Quantity { get; set; }
        public string Features { get; set; } = string.Empty;

        public IFormFile? ProfilePicture { get; set; }

    }
}
