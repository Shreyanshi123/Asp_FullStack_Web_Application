﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace backend.Models
{
    public class ProductModel
    {

        [Key]
        public int Id { get; set; }
        public string Category { get; set; }

      
        public string PName { get; set; } = string.Empty;
        public double Price { get; set; }

        public int Quantity { get; set; }
        public string Features { get; set; } = string.Empty;

        public string PicturePath { get; set; } = string.Empty;


        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

     

    }
}
