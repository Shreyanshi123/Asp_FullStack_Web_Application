﻿namespace backend.Models
{
    public class LoginModel
    {
        public string EmailId { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;


    }
}
