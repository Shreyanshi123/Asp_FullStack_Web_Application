﻿using System.ComponentModel.DataAnnotations;

namespace backend.Models
{
    public class RegistrationModel
    {
        [Key]
        public string EmailId { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;

        public string FirstName { get; set; } = string.Empty;

        public string LastName { get; set; } = string.Empty;

        public double Phone { get; set; }

        public int Age { get; set; }

        public string Roles { get; set; } = "user";

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    }
}
